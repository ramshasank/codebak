//
//  ViewController.m
//  restService
//
//  Created by Mayanka  on 6/15/15.
//  Copyright (c) 2015 Mayanka . All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *InstagramImage;
@property (strong, nonatomic) IBOutlet UITextField *InstagramTag;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)tappedOnInstagramCall:(id)sender {
    [_InstagramTag resignFirstResponder];
    NSString *BASEURL = @"https://api.instagram.com/v1/tags/";
    
    NSString *tag=@"puppy";
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *urlrest=@"/media/recent?client_id=6a62994b36e5427fa91890f03a403d5f&max_id=13872296";
    if (_InstagramTag.text.length != 0) {
        tag=_InstagramTag.text;
    }
    NSString *url = [NSString stringWithFormat:@"%@%@%@", BASEURL, tag, urlrest];
    
    NSLog(@"%@", url);
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        
        NSArray *array=[responseObject objectForKey:@"data"];
        NSDictionary *dict=[array objectAtIndex:0];
        NSDictionary *dict2=[dict objectForKey:@"images"];
        NSDictionary *dict3=[dict2 objectForKey:@"standard_resolution"];
        NSString *urlnew=[dict3 objectForKey:@"url"];
        
        [_InstagramImage setImageWithURL:([NSURL URLWithString:urlnew]) ];
                                          
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:[error description]
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
        [alert show];
    }];
}

- (IBAction)InstagramTag:(id)sender {
}
@end
